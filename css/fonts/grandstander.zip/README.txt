*Grandstander Clean - Free



Thank you for checking out this typeface (and opening this file)!

The license document has more legal information but I'd like to break it down as simply as possible here.


// What you can do with it
Just about anything you can think of. Get paid for great designs using this font! Embed it in your iphone/ipad/android/mobile application. Create logos/brands for yourself or clients with this font. Tweak the font, make it unique to you!  


// What you can't do with it:
Sell it and/or redistribute it. 


I plan on continuing to refine the font and you will receive updated files as they become available. Thank you again for your support. If you ARE using it on the web remember to add this bit of CSS 


text-rendering: optimizelegibility;


Tyler Finck
